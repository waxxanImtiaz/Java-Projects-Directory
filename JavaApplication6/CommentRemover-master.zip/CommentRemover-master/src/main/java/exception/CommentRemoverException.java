package exception;

public class CommentRemoverException extends Exception {

    public CommentRemoverException() {
        super();
    }

    public CommentRemoverException(String message) {
        super(message);
    }
}
